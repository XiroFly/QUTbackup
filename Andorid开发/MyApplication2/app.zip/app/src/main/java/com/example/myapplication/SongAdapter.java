package com.example.myapplication;
import android.app.AlertDialog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class SongAdapter extends BaseAdapter {
    private Context context;
    private List<Song> songList;

    public SongAdapter(Context context, List<Song> songList) {
        this.context = context;
        this.songList = songList;
    }

    @Override
    public int getCount() {
        return songList.size();
    }

    @Override
    public Object getItem(int position) {
        return songList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        }

        final Song song = songList.get(position);

        ImageView singerImageView = convertView.findViewById(R.id.singerImageView);
        TextView songNameTextView = convertView.findViewById(R.id.songNameTextView);
        TextView songDescriptionTextView = convertView.findViewById(R.id.songDescriptionTextView);
        CheckBox checkBox = convertView.findViewById(R.id.checkBox);

        singerImageView.setImageResource(song.getSingerImage());
        songNameTextView.setText(song.getSongName());
        songDescriptionTextView.setText(song.getSongDescription());
        checkBox.setChecked(song.isSelected());

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                song.setSelected(isChecked);
            }
        });

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAlertDialog(song.getSongName());
            }
        });

        return convertView;
    }

    private void showAlertDialog(String songName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("正在播放");
        builder.setMessage("正在播放歌曲：" + songName);
        builder.setPositiveButton("确定", null);
        builder.show();
    }
}