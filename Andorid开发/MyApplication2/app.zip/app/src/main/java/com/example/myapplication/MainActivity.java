package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// ... （原有的导入语句）

// ...（原有的导入语句）

public class MainActivity extends AppCompatActivity {
    private ListView songListView;
    private List<Song> songList;
    private SongAdapter songAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        songListView = findViewById(R.id.songListView);
        songList = new ArrayList<>();

        // 添加示例歌曲数据
        songList.add(new Song(R.drawable.jay, "反方向的钟", "周杰伦"));
        songList.add(new Song(R.drawable.khalil, "未来", "方大同"));
        songList.add(new Song(R.drawable.david, "普通朋友", "陶喆"));

        songAdapter = new SongAdapter(this, songList);
        songListView.setAdapter(songAdapter);

        // 设置长按监听器，用于选择歌曲
        songListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Song song = songList.get(position);
                song.setSelected(!song.isSelected());
                songAdapter.notifyDataSetChanged();
                return true;
            }
        });

        Button deleteButton = findViewById(R.id.deleteButton);

        // 设置删除按钮的点击事件
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteSelectedSongs();
            }
        });
    }

    private void deleteSelectedSongs() {
        // 遍历歌曲列表，删除被选中的歌曲
        Iterator<Song> iterator = songList.iterator();
        while (iterator.hasNext()) {
            Song song = iterator.next();
            if (song.isSelected()) {
                iterator.remove();
            }
        }

        // 刷新适配器以更新列表显示
        songAdapter.notifyDataSetChanged();
    }
}
