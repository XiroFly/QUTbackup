package com.example.myapplication;
public class Song {
    private int singerImage; // 用于保存歌手图片资源的ID
    private String songName;
    private String songDescription;
    private boolean isSelected;

    public Song(int singerImage, String songName, String songDescription) {
        this.singerImage = singerImage;
        this.songName = songName;
        this.songDescription = songDescription;
        this.isSelected = false;
    }

    // Getter 和 Setter 方法
    public int getSingerImage() {
        return singerImage;
    }

    public void setSingerImage(int singerImage) {
        this.singerImage = singerImage;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public String getSongDescription() {
        return songDescription;
    }

    public void setSongDescription(String songDescription) {
        this.songDescription = songDescription;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
