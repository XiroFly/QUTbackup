<%@ page contentType="text/html; charset=utf-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
  

</br>
<c:set var ="iPage" value="${param.page}" scope="page"/>
<c:if test="${empty iPage}">
	<c:set var ="iPage" value="1" scope="page"/>
</c:if>
<a href="listEL.jsp?page=1">第一页</a>
<c:if test="${iPage>1}">
	<a href="listEL.jsp?page=${iPage-1}">前一页</a>
</c:if>
<c:if test="${iPage<10}">
	<a href="listEL.jsp?page=${iPage+1}">后一页</a>
</c:if>
 <a href="list.jsp?page=10">最后一页</a>
 现在是第${iPage}页