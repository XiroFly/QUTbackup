create view pg_stat_replication
            (pid, usesysid, usename, application_name, client_addr, client_hostname, client_port, backend_start,
             backend_xmin, state, sent_lsn, write_lsn, flush_lsn, replay_lsn, write_lag, flush_lag, replay_lag,
             sync_priority, sync_state, reply_time)
as
SELECT s.pid,
       s.usesysid,
       u.rolname AS usename,
       s.application_name,
       s.client_addr,
       s.client_hostname,
       s.client_port,
       s.backend_start,
       s.backend_xmin,
       w.state,
       w.sent_lsn,
       w.write_lsn,
       w.flush_lsn,
       w.replay_lsn,
       w.write_lag,
       w.flush_lag,
       w.replay_lag,
       w.sync_priority,
       w.sync_state,
       w.reply_time
FROM pg_stat_get_activity(NULL::integer) s(datid, pid, usesysid, application_name, state, query, wait_event_type,
                                           wait_event, xact_start, query_start, backend_start, state_change,
                                           client_addr, client_hostname, client_port, backend_xid, backend_xmin,
                                           backend_type, ssl, sslversion, sslcipher, sslbits, ssl_client_dn,
                                           ssl_client_serial, ssl_issuer_dn, gss_auth, gss_princ, gss_enc, leader_pid,
                                           query_id)
         JOIN pg_stat_get_wal_senders() w(pid, state, sent_lsn, write_lsn, flush_lsn, replay_lsn, write_lag, flush_lag,
                                          replay_lag, sync_priority, sync_state, reply_time) ON s.pid = w.pid
         LEFT JOIN pg_authid u ON s.usesysid = u.oid;

alter table pg_stat_replication
    owner to postgres;

grant select on pg_stat_replication to public;

