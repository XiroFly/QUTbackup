create view pg_stat_database
            (datid, datname, numbackends, xact_commit, xact_rollback, blks_read, blks_hit, tup_returned, tup_fetched,
             tup_inserted, tup_updated, tup_deleted, conflicts, temp_files, temp_bytes, deadlocks, checksum_failures,
             checksum_last_failure, blk_read_time, blk_write_time, session_time, active_time, idle_in_transaction_time,
             sessions, sessions_abandoned, sessions_fatal, sessions_killed, stats_reset)
as
SELECT d.oid                                                                   AS datid,
       d.datname,
       CASE
           WHEN d.oid = 0::oid THEN 0
           ELSE pg_stat_get_db_numbackends(d.oid)
           END                                                                 AS numbackends,
       pg_stat_get_db_xact_commit(d.oid)                                       AS xact_commit,
       pg_stat_get_db_xact_rollback(d.oid)                                     AS xact_rollback,
       pg_stat_get_db_blocks_fetched(d.oid) - pg_stat_get_db_blocks_hit(d.oid) AS blks_read,
       pg_stat_get_db_blocks_hit(d.oid)                                        AS blks_hit,
       pg_stat_get_db_tuples_returned(d.oid)                                   AS tup_returned,
       pg_stat_get_db_tuples_fetched(d.oid)                                    AS tup_fetched,
       pg_stat_get_db_tuples_inserted(d.oid)                                   AS tup_inserted,
       pg_stat_get_db_tuples_updated(d.oid)                                    AS tup_updated,
       pg_stat_get_db_tuples_deleted(d.oid)                                    AS tup_deleted,
       pg_stat_get_db_conflict_all(d.oid)                                      AS conflicts,
       pg_stat_get_db_temp_files(d.oid)                                        AS temp_files,
       pg_stat_get_db_temp_bytes(d.oid)                                        AS temp_bytes,
       pg_stat_get_db_deadlocks(d.oid)                                         AS deadlocks,
       pg_stat_get_db_checksum_failures(d.oid)                                 AS checksum_failures,
       pg_stat_get_db_checksum_last_failure(d.oid)                             AS checksum_last_failure,
       pg_stat_get_db_blk_read_time(d.oid)                                     AS blk_read_time,
       pg_stat_get_db_blk_write_time(d.oid)                                    AS blk_write_time,
       pg_stat_get_db_session_time(d.oid)                                      AS session_time,
       pg_stat_get_db_active_time(d.oid)                                       AS active_time,
       pg_stat_get_db_idle_in_transaction_time(d.oid)                          AS idle_in_transaction_time,
       pg_stat_get_db_sessions(d.oid)                                          AS sessions,
       pg_stat_get_db_sessions_abandoned(d.oid)                                AS sessions_abandoned,
       pg_stat_get_db_sessions_fatal(d.oid)                                    AS sessions_fatal,
       pg_stat_get_db_sessions_killed(d.oid)                                   AS sessions_killed,
       pg_stat_get_db_stat_reset_time(d.oid)                                   AS stats_reset
FROM (SELECT 0          AS oid,
             NULL::name AS datname
      UNION ALL
      SELECT pg_database.oid,
             pg_database.datname
      FROM pg_database) d;

alter table pg_stat_database
    owner to postgres;

grant select on pg_stat_database to public;

